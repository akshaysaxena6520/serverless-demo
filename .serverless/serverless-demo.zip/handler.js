  const serverless = require("serverless-http");
// const express = require("express");
// const app = express();
const app = require("./src/index");

app.get("/", (req, res, next) => {
  return res.status(200).json({
    message: "Hello from root!",
  });
});

app.get("/hello", (req, res, next) => {
  return res.status(200).json({
    message: "Hello from path!",
  });
});

app.use((req, res, next) => {
  return res.status(404).json({
    error: "Not Found",
  });
});

module.exports.handler = serverless(app);


// const awsServerlessExpress = require("aws-serverless-express");
// const app = require("./src/index");

// const server = awsServerlessExpress.createServer(app);

// exports.handler = (event, context) => {
//   return awsServerlessExpress.proxy(server, event, context);
// }