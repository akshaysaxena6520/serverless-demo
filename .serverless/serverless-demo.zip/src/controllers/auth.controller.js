const signup = async (req, res) => {
  try {
    return res.status(200).json({});
  } catch (error) {
    console.log("ERROR");
  }
};

module.exports = signup;
